#ifndef USERS_H
#define USERS_H

void show_users(void);

#endif

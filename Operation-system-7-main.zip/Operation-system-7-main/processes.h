#ifndef PROCESSES_H
#define PROCESSES_H

void show_processes(void);

#endif
